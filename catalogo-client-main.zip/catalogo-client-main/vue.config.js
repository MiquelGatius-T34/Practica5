module.exports = {
  devServer: {
    disableHostCheck: true,
    port: 80,
  },
  publicPath: "/",
};
